package com.verizon.cd.ui;

import java.util.*;
import java.util.Set;

import com.verizon.cd.model.Book;

public class SetImplementationDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<Book> set1 = new HashSet<>();
		Set<Book> set2 = new LinkedHashSet<>();
		Set<Book> set3 = new TreeSet<>();
 		

	}

}
